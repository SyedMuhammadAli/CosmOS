Project Codename: Maiden

Author:
Syed Muhammad Ali	k102020
Tulsi Das Khatri	k102010

Version: v0.1

IDE		: Eclipse Indigo
Language	: Java
Platform	: Independent

Notes:
Every function is either well documented, or its functionality can be easily comprehended using its identifier�s name.

The Virtual Machine will automatically load the sample process file provided and print the state of the process registers.

The program in the given process file loads two operands from memory into R[0] and R[1], adds them, and stores the output in R[0].
